"""In-memory supplier for tests and the demo loop."""
from adapters.base import SupplierAdapter
from core.models import SupplierOffer


class MockSupplier(SupplierAdapter):
    def __init__(self, supplier_id: str, catalog: dict, fail_orders: bool = False):
        """catalog: {sku: {"cost":..., "shipping_cost":..., "stock":..., "ship_days":...}}"""
        self.supplier_id = supplier_id
        self.catalog = catalog
        self.fail_orders = fail_orders
        self.orders = {}

    def get_offers(self, sku: str) -> list:
        item = self.catalog.get(sku)
        if not item:
            return []
        return [SupplierOffer(self.supplier_id, sku, item["cost"], item["shipping_cost"], item["stock"], item["ship_days"])]

    def place_order(self, sku: str, quantity: int, address: dict) -> str:
        if self.fail_orders:
            raise RuntimeError(f"{self.supplier_id} rejected the order")
        po_id = f"{self.supplier_id}-PO-{len(self.orders) + 1}"
        self.orders[po_id] = {"sku": sku, "quantity": quantity, "tracking": None}
        self.catalog[sku]["stock"] -= quantity
        return po_id

    def get_tracking(self, po_id: str):
        return self.orders.get(po_id, {}).get("tracking")

    def ship(self, po_id: str, tracking: str) -> None:
        """Test helper: pretend the supplier shipped the parcel."""
        self.orders[po_id]["tracking"] = tracking
