"""Shopify adapter. Inbound (verify + parse) is implemented; outbound calls are TODO."""
import base64
import hashlib
import hmac
from adapters.base import StoreAdapter
from core.models import Order, OrderLine


class ShopifyAdapter(StoreAdapter):
    def __init__(self, shop_domain: str, webhook_secret: str, access_token: str = "", store_id: str = "shopify"):
        self.shop_domain = shop_domain
        self.webhook_secret = webhook_secret
        self.access_token = access_token
        self.store_id = store_id

    def verify_webhook(self, body: bytes, signature: str) -> bool:
        digest = hmac.new(self.webhook_secret.encode(), body, hashlib.sha256).digest()
        expected = base64.b64encode(digest).decode()
        return hmac.compare_digest(expected, signature or "")

    def parse_order(self, payload: dict) -> Order:
        addr = payload.get("shipping_address") or {}
        lines = [
            OrderLine(sku=li.get("sku") or "", quantity=int(li["quantity"]), unit_price=float(li["price"]))
            for li in payload.get("line_items", [])
        ]
        return Order(
            external_id=str(payload["id"]),
            store_id=self.store_id,
            customer_email=payload.get("email") or "",
            shipping_address=addr,
            lines=lines,
        )

    # TODO: implement with the Shopify Admin API (inventory levels, product variants, fulfillments).
    # Check the current API version in Shopify's docs before writing these.
    def update_inventory(self, sku: str, quantity: int) -> None:
        raise NotImplementedError

    def update_price(self, sku: str, price: float) -> None:
        raise NotImplementedError

    def push_tracking(self, order: Order, tracking: str) -> None:
        raise NotImplementedError
