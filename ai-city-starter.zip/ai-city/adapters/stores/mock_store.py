"""In-memory store for tests and the demo loop. Records every outbound call."""
from adapters.base import StoreAdapter
from core.models import Order


class MockStore(StoreAdapter):
    def __init__(self, store_id: str = "mock-store"):
        self.store_id = store_id
        self.inventory = {}
        self.prices = {}
        self.tracking = {}

    def verify_webhook(self, body: bytes, signature: str) -> bool:
        return True

    def parse_order(self, payload: dict) -> Order:
        raise NotImplementedError("MockStore receives Order objects directly")

    def update_inventory(self, sku: str, quantity: int) -> None:
        self.inventory[sku] = quantity

    def update_price(self, sku: str, price: float) -> None:
        self.prices[sku] = price

    def push_tracking(self, order: Order, tracking: str) -> None:
        self.tracking[order.external_id] = tracking
