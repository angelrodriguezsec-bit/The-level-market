"""Every store and supplier implements one of these. Adding a platform = one new adapter."""
from abc import ABC, abstractmethod
from core.models import Order, SupplierOffer


class StoreAdapter(ABC):
    store_id: str

    @abstractmethod
    def verify_webhook(self, body: bytes, signature: str) -> bool: ...

    @abstractmethod
    def parse_order(self, payload: dict) -> Order: ...

    @abstractmethod
    def update_inventory(self, sku: str, quantity: int) -> None: ...

    @abstractmethod
    def update_price(self, sku: str, price: float) -> None: ...

    @abstractmethod
    def push_tracking(self, order: Order, tracking: str) -> None: ...


class SupplierAdapter(ABC):
    supplier_id: str

    @abstractmethod
    def get_offers(self, sku: str) -> list[SupplierOffer]: ...

    @abstractmethod
    def place_order(self, sku: str, quantity: int, address: dict) -> str:
        """Return the supplier's purchase-order id. Raise on failure."""

    @abstractmethod
    def get_tracking(self, po_id: str): ...
