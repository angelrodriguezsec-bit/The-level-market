"""FastAPI entrypoint: receives store webhooks, enqueues, returns fast."""
import json
import os
from fastapi import BackgroundTasks, FastAPI, HTTPException, Request

from adapters.stores.shopify import ShopifyAdapter
from adapters.suppliers.mock_supplier import MockSupplier
from core.db import Repository
from core.events import EventBus
from core.models import Order
from services.order_service import OrderService


def create_app(service: OrderService, shopify: ShopifyAdapter, bus: EventBus, repo: Repository) -> FastAPI:
    app = FastAPI(title="AI City")
    bus.subscribe("order.received", lambda payload: service.handle_new_order(Order.from_dict(payload)))

    @app.get("/health")
    def health():
        return {"ok": True, "dead_letter": len(bus.dead_letter)}

    @app.post("/webhooks/shopify")
    async def shopify_webhook(request: Request, background: BackgroundTasks):
        body = await request.body()
        if not shopify.verify_webhook(body, request.headers.get("X-Shopify-Hmac-Sha256", "")):
            raise HTTPException(status_code=401, detail="bad signature")
        order = shopify.parse_order(json.loads(body))
        bus.publish("order.received", order.to_dict())
        background.add_task(bus.process)
        return {"queued": True}

    @app.get("/orders")
    def orders(status: str | None = None):
        return [o.to_dict() for o in repo.list_orders(status)]

    @app.get("/audit")
    def audit():
        return repo.audit()

    return app


def build_default_app() -> FastAPI:
    repo = Repository(os.environ.get("DB_PATH", "ai_city.db"))
    shopify = ShopifyAdapter(
        shop_domain=os.environ.get("SHOPIFY_DOMAIN", "example.myshopify.com"),
        webhook_secret=os.environ.get("SHOPIFY_WEBHOOK_SECRET", "change-me"),
        access_token=os.environ.get("SHOPIFY_ACCESS_TOKEN", ""),
    )
    # Replace the mock supplier with a real adapter once you have one.
    suppliers = {"demo": MockSupplier("demo", {"SKU-1": {"cost": 10.0, "shipping_cost": 3.0, "stock": 100, "ship_days": 7}})}
    service = OrderService(repo, suppliers, {shopify.store_id: shopify})
    return create_app(service, shopify, EventBus(), repo)


app = build_default_app()
