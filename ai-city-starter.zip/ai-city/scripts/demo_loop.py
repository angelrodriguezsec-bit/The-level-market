"""Run one complete order through the system with mock adapters (no network needed).
    python -m scripts.demo_loop
"""
from adapters.stores.mock_store import MockStore
from adapters.suppliers.mock_supplier import MockSupplier
from core.db import Repository
from core.events import EventBus
from core.models import Order, OrderLine
from services.inventory_sync import sync_inventory
from services.order_service import OrderService


def main():
    repo = Repository()
    store = MockStore()
    cheap_but_broken = MockSupplier("supplier_a", {"SKU-1": {"cost": 8.0, "shipping_cost": 3.0, "stock": 10, "ship_days": 12}}, fail_orders=True)
    backup = MockSupplier("supplier_b", {"SKU-1": {"cost": 10.0, "shipping_cost": 3.0, "stock": 10, "ship_days": 7}})
    suppliers = {"supplier_a": cheap_but_broken, "supplier_b": backup}
    service = OrderService(repo, suppliers, {store.store_id: store})

    print("Inventory sync:", sync_inventory(list(suppliers.values()), [store], ["SKU-1"]))

    bus = EventBus()
    bus.subscribe("order.received", lambda p: service.handle_new_order(Order.from_dict(p)))
    order = Order("1001", store.store_id, "buyer@example.com", {"country_code": "US"}, [OrderLine("SKU-1", 1, 24.99)])
    bus.publish("order.received", order.to_dict())
    bus.publish("order.received", order.to_dict())  # duplicate webhook: must be ignored
    bus.process()

    saved = repo.get_order(order.key)
    print("After sourcing:", saved.status.value, saved.fulfillment)

    po = saved.fulfillment[0]["po_id"]
    backup.ship(po, "TRACK123")
    service.poll_supplier_tracking()
    service.handle_delivered(order.key)
    final = repo.get_order(order.key)
    print("Final:", final.status.value, "| store tracking:", store.tracking)
    print("Audit entries:", len(repo.audit()), "| dead letters:", len(bus.dead_letter))


if __name__ == "__main__":
    main()
