"""Support-reply drafting with the Anthropic API. Drafts go to a human until the
agent has earned autonomy (see the staged rollout in the guide)."""
import os


def draft_support_reply(question: str, order_summary: str) -> str:
    try:
        import anthropic
    except ImportError as exc:
        raise RuntimeError("pip install anthropic") from exc

    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from the environment
    message = client.messages.create(
        model=os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5"),
        max_tokens=500,
        system=(
            "You draft customer-support replies for an online store. Be brief and polite. "
            "Only use facts from the order summary. Never promise refunds; say a team member will confirm."
        ),
        messages=[{"role": "user", "content": f"Order summary:\n{order_summary}\n\nCustomer question:\n{question}"}],
    )
    return "".join(block.text for block in message.content if block.type == "text")
