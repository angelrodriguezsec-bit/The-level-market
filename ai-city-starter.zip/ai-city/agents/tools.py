"""Tools are the ONLY way an AI agent changes anything. Limits are enforced here, in code,
not left to the model's judgment."""
from core.pricing import min_price, bounded_price


class GuardrailViolation(Exception):
    pass


class GuardedTools:
    def __init__(self, repo, stores: dict, max_change_pct=0.10, min_margin=0.20, refund_auto_cap=25.0):
        self.repo = repo
        self.stores = stores
        self.max_change_pct = max_change_pct
        self.min_margin = min_margin
        self.refund_auto_cap = refund_auto_cap

    def update_price(self, actor: str, store_id: str, sku: str, current: float, proposed: float, cost: float, shipping: float) -> float:
        floor = min_price(cost, shipping, min_margin=self.min_margin)
        if current < floor:
            raise GuardrailViolation(f"current price {current} is already below the margin floor {floor}")
        final = bounded_price(current, proposed, self.max_change_pct, floor)
        self.stores[store_id].update_price(sku, final)
        self.repo.log(actor, "update_price", {"store": store_id, "sku": sku, "from": current, "proposed": proposed, "applied": final})
        return final

    def request_refund(self, actor: str, order_key: str, amount: float) -> dict:
        status = "auto_approved" if amount <= self.refund_auto_cap else "needs_human_approval"
        # TODO: call your payment provider only when status == "auto_approved".
        self.repo.log(actor, "refund_request", {"order": order_key, "amount": amount, "status": status})
        return {"status": status, "amount": amount}
