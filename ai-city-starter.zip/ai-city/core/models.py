"""Shared data model. Every store, supplier and agent speaks these objects."""
from dataclasses import dataclass, field, asdict
from typing import Optional
from core.state_machine import OrderStatus


@dataclass
class OrderLine:
    sku: str
    quantity: int
    unit_price: float


@dataclass
class SupplierOffer:
    supplier_id: str
    sku: str
    cost: float
    shipping_cost: float
    stock: int
    ship_days: int


@dataclass
class Order:
    external_id: str
    store_id: str
    customer_email: str
    shipping_address: dict
    lines: list
    tenant_id: str = "default"  # present from day one so multi-tenancy is possible later
    status: OrderStatus = OrderStatus.RECEIVED
    fulfillment: list = field(default_factory=list)  # [{sku, supplier_id, po_id}]
    tracking: Optional[str] = None
    notes: list = field(default_factory=list)

    @property
    def key(self) -> str:
        return f"{self.tenant_id}:{self.store_id}:{self.external_id}"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @staticmethod
    def from_dict(d: dict) -> "Order":
        d = dict(d)
        d["status"] = OrderStatus(d["status"])
        d["lines"] = [OrderLine(**line) for line in d["lines"]]
        return Order(**d)
