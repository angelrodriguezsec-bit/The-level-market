"""Tiny in-memory event bus with retries and a dead-letter list.

Swap for Redis / SQS / RabbitMQ / Kafka in production. Keep the same
publish/subscribe/process interface so the rest of the code does not change.
"""
from collections import deque


class EventBus:
    def __init__(self, max_attempts: int = 3):
        self.handlers = {}
        self.queue = deque()
        self.dead_letter = []
        self.max_attempts = max_attempts

    def subscribe(self, event_type: str, handler) -> None:
        self.handlers.setdefault(event_type, []).append(handler)

    def publish(self, event_type: str, payload: dict) -> None:
        self.queue.append({"type": event_type, "payload": payload, "attempts": 0})

    def process(self) -> int:
        """Drain the queue. Failed events are retried, then dead-lettered."""
        done = 0
        while self.queue:
            event = self.queue.popleft()
            try:
                for handler in self.handlers.get(event["type"], []):
                    handler(event["payload"])
                done += 1
            except Exception as exc:  # noqa: BLE001 - we must not lose events
                event["attempts"] += 1
                event["error"] = str(exc)
                if event["attempts"] >= self.max_attempts:
                    self.dead_letter.append(event)  # shows up on the dashboard
                else:
                    self.queue.append(event)
        return done
