"""Order lifecycle. Only the transitions listed in ALLOWED are legal."""
from enum import Enum


class OrderStatus(str, Enum):
    RECEIVED = "received"
    VALIDATED = "validated"
    SOURCED = "sourced"
    ORDERED = "ordered_from_supplier"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    EXCEPTION = "exception"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"


S = OrderStatus
ALLOWED = {
    S.RECEIVED: {S.VALIDATED, S.EXCEPTION, S.CANCELLED},
    S.VALIDATED: {S.SOURCED, S.EXCEPTION, S.CANCELLED},
    S.SOURCED: {S.ORDERED, S.EXCEPTION, S.CANCELLED},
    S.ORDERED: {S.SHIPPED, S.EXCEPTION, S.CANCELLED},
    S.SHIPPED: {S.DELIVERED, S.EXCEPTION},
    S.DELIVERED: {S.REFUNDED},
    S.EXCEPTION: {S.VALIDATED, S.SOURCED, S.CANCELLED},
    S.CANCELLED: {S.REFUNDED},
    S.REFUNDED: set(),
}


class InvalidTransition(Exception):
    pass


def transition(current: OrderStatus, target: OrderStatus) -> OrderStatus:
    if target not in ALLOWED[current]:
        raise InvalidTransition(f"{current.value} -> {target.value} is not allowed")
    return target
