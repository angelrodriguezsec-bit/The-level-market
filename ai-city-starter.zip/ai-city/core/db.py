"""SQLite repository (stdlib only). Swap for Postgres by keeping this interface."""
import json
import sqlite3
import time
from typing import Optional
from core.models import Order


class Repository:
    def __init__(self, path: str = ":memory:"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS orders ("
            " key TEXT PRIMARY KEY, status TEXT, data TEXT)"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS audit_log ("
            " ts REAL, actor TEXT, action TEXT, detail TEXT)"
        )
        self.conn.commit()

    def get_order(self, key: str) -> Optional[Order]:
        row = self.conn.execute("SELECT data FROM orders WHERE key=?", (key,)).fetchone()
        return Order.from_dict(json.loads(row[0])) if row else None

    def save_order(self, order: Order) -> None:
        self.conn.execute(
            "INSERT INTO orders (key, status, data) VALUES (?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET status=excluded.status, data=excluded.data",
            (order.key, order.status.value, json.dumps(order.to_dict())),
        )
        self.conn.commit()

    def list_orders(self, status: Optional[str] = None) -> list:
        if status:
            rows = self.conn.execute("SELECT data FROM orders WHERE status=?", (status,))
        else:
            rows = self.conn.execute("SELECT data FROM orders")
        return [Order.from_dict(json.loads(r[0])) for r in rows.fetchall()]

    def log(self, actor: str, action: str, detail: dict) -> None:
        self.conn.execute(
            "INSERT INTO audit_log VALUES (?,?,?,?)",
            (time.time(), actor, action, json.dumps(detail)),
        )
        self.conn.commit()

    def audit(self) -> list:
        rows = self.conn.execute("SELECT ts, actor, action, detail FROM audit_log ORDER BY ts")
        return [
            {"ts": r[0], "actor": r[1], "action": r[2], "detail": json.loads(r[3])}
            for r in rows.fetchall()
        ]
