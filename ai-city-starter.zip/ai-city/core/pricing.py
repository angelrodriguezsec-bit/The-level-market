"""Rule-based pricing. Get this reliable before letting any AI touch prices."""
import math


def min_price(cost, shipping, fee_pct=0.029, fee_fixed=0.30, min_margin=0.20) -> float:
    """Lowest price that still earns min_margin after fees (rounded up to cents)."""
    base = (cost + shipping + fee_fixed) / (1 - fee_pct - min_margin)
    return math.ceil(base * 100) / 100


def sell_price(cost, shipping, fee_pct=0.029, fee_fixed=0.30, margin_pct=0.30) -> float:
    """Target price ending in .99 that earns at least margin_pct."""
    base = (cost + shipping + fee_fixed) / (1 - fee_pct - margin_pct)
    price = math.floor(base) + 0.99
    if price < base:
        price += 1
    return round(price, 2)


def margin(price, cost, shipping, fee_pct=0.029, fee_fixed=0.30) -> float:
    profit = price - cost - shipping - price * fee_pct - fee_fixed
    return profit / price


def bounded_price(current, proposed, max_change_pct, floor) -> float:
    """Clamp a proposed price to +/- max_change_pct of current, never below floor."""
    lo = current * (1 - max_change_pct)
    hi = current * (1 + max_change_pct)
    return round(max(floor, min(max(proposed, lo), hi)), 2)
