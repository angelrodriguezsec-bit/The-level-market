# AI City (starter)

Order automation core for dropshipping: webhook in, validate, pick supplier, reroute on failure,
tracking back to the store, guardrailed pricing/refund tools, audit log.

## Run it
    python -m unittest discover -s tests -v     # 15 tests
    python -m scripts.demo_loop                 # one full order, no network
    pip install -r requirements.txt
    uvicorn api.main:app --reload               # then POST to /webhooks/shopify

## Layout
    core/       data model, order state machine, pricing, event bus, repository
    adapters/   base interfaces + Shopify (inbound) + mocks. Add one file per platform.
    services/   order loop, sourcing, inventory sync
    agents/     guardrailed tools + LLM support drafting
    api/        FastAPI webhook receiver
    .github/    CI, deploy, dependabot, PR template

## What is real vs. still TODO
Real and tested: state machine, pricing, sourcing/reroute, idempotency, retries/dead-letter, guardrails, Shopify signature + order parsing.
TODO: Shopify outbound calls, real supplier adapters, Postgres + a real queue (Redis/SQS), payments/refund execution, auth on the API, dashboard.
