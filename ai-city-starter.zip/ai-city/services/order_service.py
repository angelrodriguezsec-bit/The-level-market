"""The order loop: receive -> validate -> source -> order from supplier -> tracking -> delivered."""
from core.models import Order
from core.state_machine import OrderStatus, transition
from services.sourcing import rank_offers


class OrderService:
    def __init__(self, repo, suppliers: dict, stores: dict):
        self.repo = repo
        self.suppliers = suppliers  # {supplier_id: SupplierAdapter}
        self.stores = stores        # {store_id: StoreAdapter}

    # ---- helpers -------------------------------------------------------
    def _move(self, order: Order, target: OrderStatus, note: str = "") -> None:
        order.status = transition(order.status, target)
        if note:
            order.notes.append(note)
        self.repo.save_order(order)
        self.repo.log("order_service", "status_change", {"order": order.key, "to": target.value, "note": note})

    def _fail(self, order: Order, reason: str) -> Order:
        self._move(order, OrderStatus.EXCEPTION, reason)
        return order

    @staticmethod
    def _problem(order: Order):
        if not order.lines:
            return "order has no lines"
        if any(line.quantity <= 0 or not line.sku for line in order.lines):
            return "invalid line (missing sku or quantity)"
        if not order.shipping_address.get("country_code") and not order.shipping_address.get("country"):
            return "missing shipping country"
        return None

    # ---- the loop ------------------------------------------------------
    def handle_new_order(self, order: Order) -> Order:
        existing = self.repo.get_order(order.key)
        if existing:                      # idempotent: webhooks arrive twice
            return existing
        self.repo.save_order(order)

        problem = self._problem(order)
        if problem:
            return self._fail(order, problem)
        self._move(order, OrderStatus.VALIDATED)

        plans = []
        for line in order.lines:
            offers = [o for s in self.suppliers.values() for o in s.get_offers(line.sku)]
            ranked = rank_offers(offers, line.quantity)
            if not ranked:
                return self._fail(order, f"no supplier stock for {line.sku}")
            plans.append((line, ranked))
        self._move(order, OrderStatus.SOURCED)

        for line, ranked in plans:
            placed = False
            for offer in ranked:          # reroute to the next supplier if one rejects
                try:
                    po_id = self.suppliers[offer.supplier_id].place_order(line.sku, line.quantity, order.shipping_address)
                except Exception as exc:  # noqa: BLE001
                    order.notes.append(f"{offer.supplier_id} failed for {line.sku}: {exc}")
                    continue
                order.fulfillment.append({"sku": line.sku, "supplier_id": offer.supplier_id, "po_id": po_id})
                placed = True
                break
            if not placed:
                return self._fail(order, f"all suppliers failed for {line.sku}")
        self._move(order, OrderStatus.ORDERED)
        return order

    def handle_shipment(self, order_key: str, tracking: str) -> Order:
        order = self.repo.get_order(order_key)
        order.tracking = tracking
        self._move(order, OrderStatus.SHIPPED, f"tracking {tracking}")
        self.stores[order.store_id].push_tracking(order, tracking)
        return order

    def handle_delivered(self, order_key: str) -> Order:
        order = self.repo.get_order(order_key)
        self._move(order, OrderStatus.DELIVERED)
        return order

    def poll_supplier_tracking(self) -> int:
        """Run on a schedule: pick up tracking numbers from suppliers."""
        updated = 0
        for order in self.repo.list_orders(OrderStatus.ORDERED.value):
            for item in order.fulfillment:
                tracking = self.suppliers[item["supplier_id"]].get_tracking(item["po_id"])
                if tracking:
                    self.handle_shipment(order.key, tracking)
                    updated += 1
                    break
        return updated
