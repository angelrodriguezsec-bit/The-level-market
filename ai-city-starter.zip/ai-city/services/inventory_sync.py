"""Push supplier stock to stores, minus a safety buffer. Pause listings at zero."""


def sync_inventory(suppliers: list, stores: list, skus: list, buffer: int = 2) -> dict:
    result = {}
    for sku in skus:
        total = sum(o.stock for s in suppliers for o in s.get_offers(sku))
        qty = max(0, total - buffer)
        for store in stores:
            store.update_inventory(sku, qty)
        result[sku] = qty
    return result
