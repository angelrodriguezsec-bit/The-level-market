"""Pick the best supplier offer: cheapest landed cost, with a small penalty per shipping day."""
from typing import Optional


def landed_cost(offer, quantity: int) -> float:
    return offer.cost * quantity + offer.shipping_cost


def rank_offers(offers: list, quantity: int, max_ship_days: Optional[int] = None, day_penalty: float = 0.5) -> list:
    usable = [
        o for o in offers
        if o.stock >= quantity and (max_ship_days is None or o.ship_days <= max_ship_days)
    ]
    return sorted(usable, key=lambda o: (landed_cost(o, quantity) + day_penalty * o.ship_days, o.supplier_id))


def choose_offer(offers: list, quantity: int, **kwargs):
    ranked = rank_offers(offers, quantity, **kwargs)
    return ranked[0] if ranked else None
