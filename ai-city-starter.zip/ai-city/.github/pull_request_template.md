## What changed
## Why
## Money-path check
- [ ] Touches pricing, refunds, or agent guardrails? Tests added/updated.
- [ ] No secrets or API keys committed.
- [ ] New adapter? Idempotency and rate limits handled.
