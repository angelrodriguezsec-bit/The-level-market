import unittest

from adapters.stores.mock_store import MockStore
from adapters.stores.shopify import ShopifyAdapter
from adapters.suppliers.mock_supplier import MockSupplier
from agents.tools import GuardedTools, GuardrailViolation
from core.db import Repository
from core.events import EventBus
from core.models import Order, OrderLine, SupplierOffer
from core.pricing import bounded_price, margin, min_price, sell_price
from core.state_machine import InvalidTransition, OrderStatus, transition
from services.order_service import OrderService
from services.sourcing import choose_offer


def make_order(ext="1", sku="SKU-1", qty=1, country="US"):
    return Order(ext, "mock-store", "a@b.com", {"country_code": country}, [OrderLine(sku, qty, 24.99)])


class StateMachineTests(unittest.TestCase):
    def test_valid_and_invalid(self):
        self.assertEqual(transition(OrderStatus.RECEIVED, OrderStatus.VALIDATED), OrderStatus.VALIDATED)
        with self.assertRaises(InvalidTransition):
            transition(OrderStatus.RECEIVED, OrderStatus.DELIVERED)


class PricingTests(unittest.TestCase):
    def test_sell_price_meets_margin_and_ends_99(self):
        price = sell_price(10, 3, margin_pct=0.30)
        self.assertTrue(str(price).endswith(".99"))
        self.assertGreaterEqual(margin(price, 10, 3), 0.30)

    def test_min_price_and_bounds(self):
        floor = min_price(10, 3, min_margin=0.20)
        self.assertGreaterEqual(margin(floor, 10, 3), 0.19999)
        self.assertEqual(bounded_price(20.0, 40.0, 0.10, floor), 22.0)   # capped at +10%
        self.assertEqual(bounded_price(20.0, 1.0, 0.10, floor), max(floor, 18.0))


class SourcingTests(unittest.TestCase):
    def test_picks_cheapest_in_stock(self):
        offers = [
            SupplierOffer("a", "S", 8, 3, 0, 5),    # out of stock
            SupplierOffer("b", "S", 10, 3, 5, 7),
            SupplierOffer("c", "S", 9, 3, 5, 7),
        ]
        self.assertEqual(choose_offer(offers, 1).supplier_id, "c")

    def test_none_when_no_stock(self):
        self.assertIsNone(choose_offer([SupplierOffer("a", "S", 8, 3, 0, 5)], 1))


class OrderLoopTests(unittest.TestCase):
    def setUp(self):
        self.repo = Repository()
        self.store = MockStore()
        self.a = MockSupplier("a", {"SKU-1": {"cost": 8, "shipping_cost": 3, "stock": 5, "ship_days": 7}}, fail_orders=True)
        self.b = MockSupplier("b", {"SKU-1": {"cost": 10, "shipping_cost": 3, "stock": 5, "ship_days": 7}})
        self.service = OrderService(self.repo, {"a": self.a, "b": self.b}, {"mock-store": self.store})

    def test_reroutes_when_first_supplier_fails(self):
        order = self.service.handle_new_order(make_order())
        self.assertEqual(order.status, OrderStatus.ORDERED)
        self.assertEqual(order.fulfillment[0]["supplier_id"], "b")

    def test_duplicate_webhook_is_ignored(self):
        self.service.handle_new_order(make_order())
        self.service.handle_new_order(make_order())
        self.assertEqual(len(self.repo.list_orders()), 1)
        self.assertEqual(len(self.b.orders), 1)

    def test_out_of_stock_goes_to_exception(self):
        order = self.service.handle_new_order(make_order(sku="MISSING"))
        self.assertEqual(order.status, OrderStatus.EXCEPTION)

    def test_invalid_order_goes_to_exception(self):
        order = self.service.handle_new_order(make_order(country=""))
        self.assertEqual(order.status, OrderStatus.EXCEPTION)

    def test_full_lifecycle_pushes_tracking(self):
        order = self.service.handle_new_order(make_order())
        self.b.ship(order.fulfillment[0]["po_id"], "T1")
        self.assertEqual(self.service.poll_supplier_tracking(), 1)
        self.assertEqual(self.store.tracking["1"], "T1")
        self.assertEqual(self.service.handle_delivered(order.key).status, OrderStatus.DELIVERED)


class EventBusTests(unittest.TestCase):
    def test_retries_then_dead_letters(self):
        bus = EventBus(max_attempts=3)
        calls = []

        def bad(_):
            calls.append(1)
            raise RuntimeError("boom")

        bus.subscribe("x", bad)
        bus.publish("x", {})
        bus.process()
        self.assertEqual(len(calls), 3)
        self.assertEqual(len(bus.dead_letter), 1)


class GuardrailTests(unittest.TestCase):
    def setUp(self):
        self.repo = Repository()
        self.store = MockStore()
        self.tools = GuardedTools(self.repo, {"mock-store": self.store})

    def test_price_change_is_clamped_and_logged(self):
        applied = self.tools.update_price("pricing_agent", "mock-store", "SKU-1", 25.0, 100.0, 10, 3)
        self.assertEqual(applied, 27.5)
        self.assertEqual(self.store.prices["SKU-1"], 27.5)
        self.assertEqual(self.repo.audit()[-1]["action"], "update_price")

    def test_refund_over_cap_needs_human(self):
        self.assertEqual(self.tools.request_refund("support_agent", "k", 10)["status"], "auto_approved")
        self.assertEqual(self.tools.request_refund("support_agent", "k", 500)["status"], "needs_human_approval")

    def test_price_below_floor_rejected(self):
        with self.assertRaises(GuardrailViolation):
            self.tools.update_price("pricing_agent", "mock-store", "SKU-1", 5.0, 6.0, 10, 3)


class ShopifyTests(unittest.TestCase):
    def test_signature_and_parse(self):
        import base64
        import hashlib
        import hmac
        adapter = ShopifyAdapter("x.myshopify.com", "secret")
        body = b'{"id": 1}'
        sig = base64.b64encode(hmac.new(b"secret", body, hashlib.sha256).digest()).decode()
        self.assertTrue(adapter.verify_webhook(body, sig))
        self.assertFalse(adapter.verify_webhook(body, "wrong"))
        order = adapter.parse_order({
            "id": 99, "email": "a@b.com",
            "shipping_address": {"country_code": "US"},
            "line_items": [{"sku": "SKU-1", "quantity": 2, "price": "12.50"}],
        })
        self.assertEqual(order.external_id, "99")
        self.assertEqual(order.lines[0].quantity, 2)


if __name__ == "__main__":
    unittest.main()
